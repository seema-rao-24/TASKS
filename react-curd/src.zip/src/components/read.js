
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';


export default function Read(){
    const [APIData, setAPIData] = useState([]);
    useEffect(() => {
    axios.get(`https://6120cbe224d11c001762eda1.mockapi.io/fakeData`)
        .then((response) => {
            setAPIData(response.data);
        })
    }, [])
    
     const setData = (data) => {
        let { id, firstName, lastName, checkbox } = data;
        localStorage.setItem('ID', id);
        localStorage.setItem('First Name', firstName);
        localStorage.setItem('Last Name', lastName);
        localStorage.setItem('Checkbox Value', checkbox)
    }
    const getData = () => {
        axios.get(`https://6120cbe224d11c001762eda1.mockapi.io/fakeData`)
            .then((getData) => {
                 setAPIData(getData.data);
             })
    }

    const onDelete = (id) => {
        axios.delete(`https://6120cbe224d11c001762eda1.mockapi.io/fakeData/${id}`)
        .then(() => {
            getData();
      })
    }

    return(
        <div>
            <table class="table table-striped table-success">
            <thead>
                <tr>    
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Checked</th>
                <th scope="col">Update</th>
                <th scope="col">Delete</th>
                </tr>
            </thead>
            <tbody>
                {APIData.map((data) => {
                    return (
                    <tr>
                        <td>{data.firstName}</td>
                        <td>{data.lastName}</td>
                        <td>{data.checkbox ? 'Checked' : 'Unchecked'}</td>
                        <td> 
                        <Link to='/update'>
                           
                                <button onClick={() => setData(data)}>Update</button>
                            
                        </Link></td>
                        <td><button onClick={() => onDelete(data.id)}>Delete</button></td>
                    </tr>
                )})}
                
            </tbody>
            </table>
        </div>
        
    )

}