
import axios from 'axios';
import React, { useState,useEffect } from 'react';

export default function Update(){
    
    const [firstName,setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [checkbox, setCheckbox] = useState(false);
    const [id, setID] = useState(null);

        useEffect(() => {
                setID(localStorage.getItem('ID'))
                setFirstName(localStorage.getItem('First Name'));
                setLastName(localStorage.getItem('Last Name'));
                setCheckbox(localStorage.getItem('Checkbox Value'))
        }, []);

        const updateAPIData = (e) => {
            e.preventDefault();
            axios.put(`https://6120cbe224d11c001762eda1.mockapi.io/fakeData/${id}`, {
                firstName,
                 lastName,
                 checkbox
            })
        }
    
return (
    
    <form className="create-form">
            <div className="mb-3">
                <label className="form-label">First Name</label>
                <input type="text" className="form-control" value={firstName} onChange={(e) => setFirstName(e.target.value)}/>
                
            </div>
            <div className="mb-3">
                <label className="form-label">Last Name</label>
                <input type="text"  className="form-control" value={lastName} onChange={(e) => setLastName(e.target.value)}/>
            </div>
            <div className="mb-3 form-check">
                <input type="checkbox" checked={checkbox} onChange={(e) => setCheckbox(!checkbox)}/>
                <label className="form-check-label"> Check me out</label>
            </div>
        <button type="submit" onClick={updateAPIData} className="btn btn-primary">Update</button>
    </form>
    
)
}