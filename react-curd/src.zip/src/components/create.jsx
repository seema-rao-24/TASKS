import React, {useState} from 'react';
import axios from 'axios';

export default function Create(){
    const [firstName,setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [checkbox, setCheckbox] = useState(false);
    const postData = (e) => {
        e.preventDefault();
        axios.post(`https://6120cbe224d11c001762eda1.mockapi.io/fakeData`, {
            firstName,
            lastName,
            checkbox 
        })
        console.log(firstName);
        console.log(lastName);
        console.log(checkbox);
        }
return (
    
    <form className="create-form">
            <div className="mb-3">
                <label className="form-label">First Name</label>
                <input type="text" className="form-control" onChange={(e) => setFirstName(e.target.value)}/>
                
            </div>
            <div className="mb-3">
                <label className="form-label">Last Name</label>
                <input type="text"  className="form-control" onChange={(e) => setLastName(e.target.value)}/>
            </div>
            <div className="mb-3 form-check">
                <input type="checkbox"  onChange={(e) => setCheckbox(!checkbox)}/>
                <label className="form-check-label"> Check me out</label>
            </div>
        <button onClick={postData} type="submit" className="btn btn-primary">Submit</button>
    </form>
    
)
}
