import { Link } from "react-router-dom";
const Home = () =>{
    return (
        <div>
        <div className="container">
        <br></br>
            <div className="row">
                <div className="col-md-4 col-12">
                <div className="card border-0">
                    <div className="card-body shadow rounded">
                    <h5 className="card-title">Become a UI developer</h5>
                    
                    <Link to="/" className="btn btn-primary">Know More
                    </Link>
                    </div>
                </div>
                </div>
                <div className="col-md-4 col-12">
                <div className="card border-0">
                    <div className="card-body shadow rounded">
                    <h5 className="card-title">Become a Angular Developer</h5>
                    
                    {/* <a href="#" className="btn btn-primary">Know More</a> */}
                    <Link to="/" className="btn btn-primary">Know More
                    </Link>
                    </div>
                </div>
                </div>
                <div className="col-md-4 col-12">
                <div className="card border-0">
                    <div className="card-body shadow rounded">
                    <h5 className="card-title">Become a ReactJS Developer</h5>
                    
                    <Link to="/" className="btn btn-primary">Know More
                    </Link>
                    </div>
                </div>
                </div>
            </div>
            
        </div>
        <br></br>
        <div className="col-md-12 text-center bg-info p-2">
            <h5 className="font-bold text-white pad-10 line-h-1 know-us-font">Enroll, Learn, Grow, Repeat! Get ready to achieve
                your learning goals with Acheivers IT
            </h5>
            <a className="btn-white" href="#">CONTACT US</a>
        </div> 
        <div className="container">
        <img src="https://www.achieversit.com/assets/images/process.jpg" class="w-100" alt="ait-process"></img>
        </div>
        </div>
        
    
    );
};
export default Home;