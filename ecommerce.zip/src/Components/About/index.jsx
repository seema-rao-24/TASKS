const About = () => {
    return(
        <p>About page</p>
    )
};
export default About;