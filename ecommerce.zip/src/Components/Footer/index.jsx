import Faclogo from "../../images/facebook_social_icon.png"
import Twitterlogo from "../../images/social_twitter_icon.png"
import Linkedlogo from "../../images/linkedin_social_media_icon.png"
const Footer = () =>{
    return (
        <div class="footer bg-secondary bg-gradient">
        <div class="col-md-12  social-icons text-center">
		    <ul class="social-network social-circle p-2">
                <li class="d-inline"><a href="https://www.facebook.com/AchieversITTrainings/" rel="nofollow" class="icoFacebook" title="Facebook" target="_blank"><img src={Faclogo}/></a></li>
                <li class="d-inline"><a href="https://www.linkedin.com/company/achieversit-solutions/?viewAsMember=true" rel="nofollow" class="icoLinkedin" title="Linkedin" target="_blank"><img src={Linkedlogo}/></a></li>
                <li class="d-inline"><a href="https://twitter.com/it_achievers" class="iconTwitter" title="Twitter" rel="nofollow" target="_blank"><img src={Twitterlogo}/></a></li>
			
		    </ul>
	    </div>
        <div class="col-md-12">
            <div class="py-4 d-flex justify-content-center text-white">
            <p class="p-2 pe-5">Copyright © 2020 AchieversIT. All Rights Reserved
		    </p>
            <a class="p-2 text-white text-decoration-none">Privacy Policy</a>
            <a class="p-2 text-white text-decoration-none">Terms of use</a>
            <a class="p-2 text-white text-decoration-none">Refund Policy</a>
            </div>
        </div>
        </div>
    );
    
};
export default Footer;