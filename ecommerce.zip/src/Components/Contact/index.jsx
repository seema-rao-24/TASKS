const Contact = () =>{
    return <p>Contact page</p>;
    
};
export default Contact;