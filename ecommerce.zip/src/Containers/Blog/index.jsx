import React, { Component } from "react";

class Blogs extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            blogs:[
                {
                    name: "Samsung 138 cm (55 inches) Crystal 4K Series 1",
                    subtitle: "Samsung 138 cm",
                    description: `Resolution : Crystal 4K UHD (3840 x 2160) resolution | Refresh Rate : 60 Hertz
                    Connectivity: 3 HDMI ports to connect set top box, Blu-ray speakers or a gaming console | 1 USB ports to connect hard drives or other USB devices`,
                    imgurl: "../../images/samsung.jpg",
                  },
                  {
                    name: "Samsung 138 cm (55 inches) Crystal 4K Series 2",
                    subtitle: "Samsung 138 cm",
                    description: `Resolution : Crystal 4K UHD (3840 x 2160) resolution | Refresh Rate : 60 Hertz
                      Connectivity: 3 HDMI ports to connect set top box, Blu-ray speakers or a gaming console | 1 USB ports to connect hard drives or other USB devices`,
                    imgurl: "../../images/samsung.jpg",
                  },
                  {
                    name: "Samsung 138 cm (55 inches) Crystal 4K Series 3",
                    subtitle: "Samsung 138 cm",
                    description: `Resolution : Crystal 4K UHD (3840 x 2160) resolution | Refresh Rate : 60 Hertz
                      Connectivity: 3 HDMI ports to connect set top box, Blu-ray speakers or a gaming console | 1 USB ports to connect hard drives or other USB devices`,
                    imgurl: "../../images/samsung.jpg",
                  }
            ],
            users:[],
        };
    }
    componentDidMount(){
        fetch("https://jsonplaceholder.typicode.com/users")
        .then((response)=>response.json())
        .then((data)=>{
            this.setState({...this.state,users:data});
            console.log(this.state.users);
        });
    }
    render(){
        let allBlogs = this.state.blogs.map((item,index)=>{
            return(
                <div className="col-md-4">
                    <div className="card">
                        <div className="card-body">
                        <h5 className="card-title">{item.name}</h5>
                        <h6 className="card-subtitle mb-2 text-muted">{item.subtitle}</h6>
                        <p className="card-text">{item.description}</p>
                        <a href="#" className="card-link">
                            More
                        </a>
                        <a href="#" className="card-link">
                            Comments
                        </a>
                        </div>
                    </div>
                </div>
            );

        });
        let allUsers = this.state.users.map((itm,index)=>{
            return(
                        <tr>
                            <td>{itm.id}</td>
                            <td>{itm.name}</td>
                            <td>{itm.username}</td>
                            <td>{itm.email}</td>
                            <td>{itm.address.street}, {itm.address.suite}, {itm.address.city}, {itm.address.zipcode}</td>
                        </tr>                
            );

        });
        return (
            <>
              <section className="container">
                <div className="row">
                  <h1>Blogs</h1>
                  {allBlogs}
                  
                </div>
              </section>
              <br/>
              <section className="container">
              <div class="table-responsive">
              <table className="table table-bordered">
              <thead>
                        <tr>
                            <th scope="col">id</th>
                            <th scope="col">names</th>
                            <th scope="col">usernames</th>
                            <th scope="col">emails</th>
                            <th scope="col">address</th>
                        </tr>
                        {allUsers}
              </thead>
              </table>
              </div>
              </section>
              
            </>
          );
    }

}

export default Blogs;