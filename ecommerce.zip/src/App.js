import logo from './logo.svg';
import './App.css';

import { BrowserRouter as Router,Switch,Route } from 'react-router-dom';
import Header from './Components/Header';
import Slider from './Components/Slider';
import Footer from './Components/Footer';
import About from './Components/About';
import Services from './Containers/Services';
import Home from './Components/Home';
import Blog from './Containers/Blog';
import Clients from './Containers/Clients';
import Contact from './Components/Contact';

function App() {
  return (
    <>
      <Router>
        <Header/>
        <Slider/>
        <Switch>
          <Route path="/" component={Home} exact></Route>
          <Route path="/about" component={About} exact></Route>
          <Route path="/services" component={Services} exact></Route>
          <Route path="/clients" component={Clients} exact></Route>
          <Route path="/blog" component={Blog} exact></Route>
          <Route path="/contact" component={Contact} exact></Route>
        </Switch>
        <Footer/>
      </Router>
    </>
    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>
  );
}

export default App;
